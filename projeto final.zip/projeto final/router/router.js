export function appRouter(){
    return(
        <browserrouter>
        <routers>
            <router path="/" element=(index2/>)/>
            <router path="/" element=(index3/>)/>
        </routers>
        </browserrouter>
    )

}